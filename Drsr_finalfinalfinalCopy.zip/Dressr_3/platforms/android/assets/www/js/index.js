/* 
 Student: Kim Montes <monteski@sheridan.desire2learn.com>
 StudentID: 991369500
 Course: SYST35300
 Project: Drsr
 */
var db;
var item;
var redoCount = 0;
var app = {
    initialize: function () {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },
    onDeviceReady: function () {
        document.getElementById("refresh").addEventListener("click", generateLook, false);
        document.getElementById("clearDBBtn").addEventListener("click", clearDB, false);
        document.getElementById("submitBtn").addEventListener("click", addClothing, false);
        document.getElementById("takePhoto").addEventListener("click", takePhoto, false);
        $(document).on("pagebeforeshow", "#submitPage", function () {
            changePage("Area1");
        });
    }
};//app

function indexedDBOk() {
    return "indexedDB" in window;
}//indexedDBok

document.addEventListener("DOMContentLoaded", function () {
    if (!indexedDBOk) {
        return;
    }
    var openRequest = indexedDB.open("Drsr", 1);
    openRequest.onupgradeneeded = function (e) {
        var thisDB = e.target.result;
        if (!thisDB.objectStoreNames.contains("Sweaters")) {
            thisDB.createObjectStore("Sweaters", {autoIncrement: true});
        }
        if (!thisDB.objectStoreNames.contains("Shirts")) {
            thisDB.createObjectStore("Shirts", {autoIncrement: true});
        }
        if (!thisDB.objectStoreNames.contains("Pants")) {
            thisDB.createObjectStore("Pants", {autoIncrement: true});
        }
    };
    openRequest.onsuccess = function (e) {
        db = e.target.result;
    };
    openRequest.onerror = function (e) {
    };
}, false);//DOMContentLoaded event listener

function clearDB() {
    function onConfirm(buttonIndex) {
        if (buttonIndex === 1) {
            var transaction = db.transaction(["Sweaters"], "readwrite");
            var store = transaction.objectStore("Sweaters");
            var request = store.clear();
            var transaction2 = db.transaction(["Shirts"], "readwrite");
            var store2 = transaction2.objectStore("Shirts");
            var request2 = store2.clear();
            var transaction3 = db.transaction(["Pants"], "readwrite");
            var store3 = transaction3.objectStore("Pants");
            var request3 = store3.clear();
        }
    }
    navigator.notification.confirm(
            'Are you sure you wanna clear the database?',
            onConfirm,
            'Drsr',
            ['Yes', 'No']
            );
}//clearDB

function generateLook() {
    getSweater();
}//generateLook

function getSweater() {
    var transaction = db.transaction(["Sweaters"], "readonly");
    var store = transaction.objectStore("Sweaters");
    var count = transaction.objectStore("Sweaters").count();
    count.onsuccess = function (e) {
        var numItems = count['result'];
        if (numItems === 0) {
            function alertDismissed() {
                $("#sweaterArea").html("");
                $("#shirtArea").html("");
                $("#pantsArea").html("");
                redoCount = 0;
            }
            navigator.notification.alert(
                    'Yikes! Try putting more clothes.',
                    alertDismissed,
                    'Drsr',
                    'Done'
                    );
        } else {
            var tempcount = 1;
            var ID = 0;
            var randNum = Math.floor((Math.random() * numItems) + 1);
            var request2 = store.openCursor();
            request2.onsuccess = function (e) {
                var cursor = e.target.result;
                if (cursor) {
                    if (tempcount === randNum) {
                        ID = cursor.key;
                        var request = store.get(Number(ID));
                        request.onsuccess = function (e) {
                            var result = e.target.result;
                            if (result) {
                                item = result.value;
                                $("#" + "sweaterArea").html("");
                                createCell("sweaterArea", result, 1);
                                getShirt();
                            } else {
                            }
                        };
                        request.onerror = function (e) {
                        };
                    }
                    tempcount++;
                    cursor.continue();
                }
            };
        }
    };
}//getSweater

function getShirt() {
    var transaction = db.transaction(["Shirts"], "readonly");
    var store = transaction.objectStore("Shirts");
    var count = transaction.objectStore("Shirts").count();
    count.onsuccess = function (e) {
        var numItems = count['result'];
        if (numItems === 0) {
            function alertDismissed() {
                $("#sweaterArea").html("");
                $("#shirtArea").html("");
                $("#pantsArea").html("");
                redoCount = 0;
            }
            navigator.notification.alert(
                    'Yikes! Try putting more clothes.',
                    alertDismissed,
                    'Drsr',
                    'Done'
                    );
        } else {
            var tempcount = 1;
            var ID = 0;
            var randNum = Math.floor((Math.random() * numItems) + 1);
            var request2 = store.openCursor();
            request2.onsuccess = function (e) {
                var cursor = e.target.result;
                if (cursor) {
                    if (tempcount === randNum) {
                        ID = cursor.key;
                        var request = store.get(Number(ID));
                        request.onsuccess = function (e) {
                            var result = e.target.result;
                            var item = result.value;
                            if (result) {
                                $("#" + "shirtArea").html("");
                                createCell("shirtArea", result, 1);
                                getPants();
                            } else {
                            }
                        };
                        request.onerror = function (e) {
                        };
                    }
                    tempcount++;
                    cursor.continue();
                }
            };
        }
    };
}//getShirt

function getPants() {
    var transaction = db.transaction(["Pants"], "readonly");
    var store = transaction.objectStore("Pants");
    var count = transaction.objectStore("Pants").count();
    count.onsuccess = function (e) {
        var numItems = count['result'];
        if (numItems === 0) {
            function alertDismissed() {
                $("#sweaterArea").html("");
                $("#shirtArea").html("");
                $("#pantsArea").html("");
                redoCount = 0;
            }
            navigator.notification.alert(
                    'Yikes! Try putting more clothes.',
                    alertDismissed,
                    'Drsr',
                    'Done'
                    );
        } else {
            var tempcount = 1;
            var ID = 0;
            var randNum = Math.floor((Math.random() * numItems) + 1);
            var request2 = store.openCursor();
            request2.onsuccess = function (e) {
                var cursor = e.target.result;
                if (cursor) {
                    if (tempcount === randNum) {
                        ID = cursor.key;
                        var request = store.get(Number(ID));
                        request.onsuccess = function (e) {
                            var result = e.target.result;
                            var item = result.value;
                            if (result) {
                                $("#" + "pantsArea").html("");
                                createCell("pantsArea", result, 1);
                                testResults();
                            } else {
                            }
                        };
                        request.onerror = function (e) {
                        };
                    }
                    tempcount++;
                    cursor.continue();
                }
            };
        }
    };
}//getPants

function testResults() {
    if (redoCount < 10) {
        var bleh = ["orangegreen", "pinkbronze", "redpurple", "silveryellow", "blueyellow", "brownmaroon", "purpleyellow", "brownblack", "orangepink", "yellowbrown"];
        var badGrouping = false;
        var sweater = $("#sweaterAreacell1").html();
        var shirt = $("#shirtAreacell1").html();
        var pants = $("#pantsAreacell1").html();
        var sweaterArr = sweater.split(" ");
        var shirtArr = shirt.split(" ");
        var pantsArr = pants.split(" ");
        var sweaterColor;
        var sweaterPattern = false;
        var shirtColor;
        var shirtPattern = false;
        var pantsColor;
        var pantsPattern = false;
        sweaterColor = sweaterArr[1].toLowerCase();
        if (sweaterArr[2] === "") {
        } else {
            sweaterPattern = true;
        }
        shirtColor = shirtArr[1].toLowerCase();
        if (shirtArr[2] === "") {
        } else {
            shirtPattern = true;
        }
        pantsColor = pantsArr[1].toLowerCase();
        if (pantsArr[2] === "") {
        } else {
            pantsPattern = true;
        }
        for (var i = 0; i < bleh.length; i++) {
            if ((sweaterColor + shirtColor) === bleh[i] || (shirtColor + sweaterColor) === bleh[i]) {
                badGrouping = true;
            }
        }
        if (badGrouping === true) {
            getShirt();
        } else {
            badGrouping = false;
            for (var i = 0; i < bleh.length; i++) {
                if ((pantsColor + shirtColor) === bleh[i] || (shirtColor + pantsColor) === bleh[i]) {
                    badGrouping = true;
                }
            }
            if (badGrouping === true) {
                getPants();
            }
        }
        if (sweaterPattern === true && shirtPattern === false && pantsPattern === false) {
        } else if (sweaterPattern === false && shirtPattern === true && pantsPattern === false) {
        } else if (sweaterPattern === false && shirtPattern === false && pantsPattern === true) {
        } else if (sweaterPattern === false && shirtPattern === false && pantsPattern === false) {
        } else {
            alert("Redo");
            redoCount++;
            generateLook();
        }
    } else if (redoCount === 10) {
        function alertDismissed() {
            $("#sweaterArea").html("");
            $("#shirtArea").html("");
            $("#pantsArea").html("");
            redoCount = 0;
        }
        navigator.notification.alert(
                'Yikes! We couldnt find a match. Try putting more clothes.',
                alertDismissed,
                'Drsr',
                'Done'
                );
    }
}//testResults

function changePage(location) {
    $("#sweaterArea").html("");
    $("#shirtArea").html("");
    $("#pantsArea").html("");
    for (i = 1; i < 4; i++) {
        $("#Area" + i).hide();
    }
    $("#" + location).show();
    var getItemsFor = $("#itemType option:selected").text();
    var sub = getItemsFor.substring(0, getItemsFor.length - 1);
    $("#" + sub + "cards").html("");
    getItems(sub);
}//changePage

function getItems(cell) {
    var transaction = db.transaction([cell + "s"], "readonly");
    var store = transaction.objectStore(cell + "s");
    var request = store.openCursor();
    var idNum = 0;
    request.onsuccess = function (e) {
        var cursor = e.target.result;
        if (cursor) {
            createCell(cell + "cards", cursor.value, idNum);
            cursor.continue();
            idNum++;
        }
    };
    request.onerror = function (e) {
    };
}//getItems

function createCell(cell, item, idNum) {
    var image1 = item.image1;
    var color = item.color;
    var itemTypes = item.itemTypes;
    var shadeItems = item.shadeItems;
    var itemPattern = item.itemPattern;
    var hasPattern = "";
    if (itemPattern === "Yes") {
        hasPattern = "Patterned";
    }
    $("#" + cell).append(
            "<div class='card'>" +
            "<div class='container'>" +
            "<h4><b class='test2' id='" + cell + "cell" + idNum + "'>" + shadeItems + " " + color + " " + hasPattern + " " + itemTypes + "</b></h4> " +
            "<center id='test'>" +
            "<img style='visibility: visible; align-self: center; width:75px; height: 75px;' id='img1' src=" + image1 + ">" +
            "</center>" +
            "</div>" +
            "</div>"
            );
    var id = cell + "cell" + idNum;
    document.getElementById(cell + "cell" + idNum).addEventListener("click",
            function () {
                deleteItem(item, id, cell);
            }
    , false);
}//getItems

function deleteItem(item, id, cell) {
    var dbName = cell.split("cards");
    if (id !== "sweaterAreacell1" || id !== "shirtAreacell1" || id !== "pantsAreacell1") {
        var transaction = db.transaction([dbName[0] + "s"], "readwrite");
        var store = transaction.objectStore(dbName[0] + "s");
        var request = store.openCursor();
        request.onsuccess = function (e) {
            var cursor = e.target.result;
            if (cursor) {
                var tempItem = cursor.value;
                if (JSON.stringify(item) === JSON.stringify(tempItem)) {
                    var tempItemID = cursor.key;
                    function onConfirm(buttonIndex) {
                        if (buttonIndex === 1) {
                            var transaction2 = db.transaction([dbName[0] + "s"], "readwrite");
                            var store2 = transaction2.objectStore(dbName[0] + "s");
                            var request2 = store2.delete(Number(tempItemID));
                            request2.onsuccess = function (e) {
                                if (dbName[0] === "Sweater") {
                                    changePage("Area1");
                                } else if (dbName[0] === "Shirt") {
                                    changePage("Area2");
                                } else if (dbName[0] === "Pant") {
                                    changePage("Area3");
                                }
                            };
                            request2.onerror = function (e) {
                                alert("bad delete");
                            };
                        }
                    }
                    navigator.notification.confirm(
                            'Are you sure you wanna Delete this?',
                            onConfirm,
                            'Drsr',
                            ['Yes', 'No']
                            );
                }
                cursor.continue();
            }
        };
        request.onerror = function (e) {
        };
    }
}//deleteItem

function addClothing() {
    var image1 = document.getElementById("tempImage").src;
    var color = $("#color option:selected").val();
    var itemTypes = $("#itemTypes option:selected").val();
    var shadeItems = $("#shadeItems option:selected").val();
    var itemPattern = $("#itemPattern option:selected").text();
    var clothing = "";
    clothing = {
        image1: image1,
        color: color,
        itemTypes: itemTypes,
        shadeItems: shadeItems,
        itemPattern: itemPattern
    };
    addToDB(clothing);
    document.getElementById("tempImage").src = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==";
}//addClothing

function addToDB(clothing) {
    var transaction = db.transaction([clothing.itemTypes + "s"], "readwrite");
    var store = transaction.objectStore(clothing.itemTypes + "s");
    var request = store.add(clothing);
    request.onerror = function (e) {
    };
    request.onsuccess = function (e) {
    };
}//addToDB

function takePhoto() {
    var options = {
        destinationType: Camera.DestinationType.FILE_URL,
        cameraDirection: Camera.Direction.FRONT,
        encodingType: Camera.EncodingType.JPEG,
        correctOrientation: true,
        allowEdit: true,
        targetWidth: 250,
        targetHeight: 250
    };
    navigator.camera.getPicture(cameraSuccess, cameraFail, options);
}//takePhoto

function cameraSuccess(imageData) {
    document.getElementById("tempImage").src = imageData;
    $("#img1").css({"visibility": "visible"});
}//cameraSuccess

function cameraFail(errorObj) {
}//cameraFail
app.initialize();